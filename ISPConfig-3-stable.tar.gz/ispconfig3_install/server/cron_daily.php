<?php

// the cron daily file is no longer used and was replaced by cron.php


?>