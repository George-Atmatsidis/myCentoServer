#!/bin/bash

CUR=`dirname $0`
bash ${CUR}/update_from_dev.sh

exit 0